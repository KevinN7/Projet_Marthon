imf = fft2(im);
%imfn = imf/sqrt(nlig*ncol);
imfn = fft2(imn);