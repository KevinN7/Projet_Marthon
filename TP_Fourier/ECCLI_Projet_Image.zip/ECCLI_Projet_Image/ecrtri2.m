% Ecriture d'une image IM au format TRIMAGO (suffixe .tri) monochrome ou trichrome
% NOMFIC contient le nom du fichier sans son suffixe
%