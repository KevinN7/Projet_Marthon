% Calcul du module de la transformée de Fourier de l'image normalisée

imfa = abs(imfn);
figure;
imagesc(imfa);